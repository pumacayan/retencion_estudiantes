# 🎓 RESUMEN EJECUTIVO - App de Predicción de Retención Estudiantil

## 📊 Resultados del Modelo

### Precisión General: **77.97%**

| Categoría | Precisión | Recall | F1-Score | Soporte |
|-----------|-----------|--------|----------|---------|
| **Dropout (Abandono)** | 82% | 77% | 79% | 284 estudiantes |
| **Enrolled (Inscrito)** | 63% | 32% | 42% | 159 estudiantes |
| **Graduate (Graduado)** | 78% | 95% | 86% | 442 estudiantes |

### Interpretación
- ✅ **Excelente** para predecir graduados (95% recall)
- ✅ **Muy bueno** para predecir abandonos (82% precisión)
- ⚠️ **Moderado** para predecir inscritos (requiere mejora)

---

## 🔝 Top 10 Variables Más Importantes

| # | Variable | Importancia |
|---|----------|-------------|
| 1 | Unidades curriculares aprobadas (2S) | 20.1% |
| 2 | Unidades curriculares aprobadas (1S) | 13.0% |
| 3 | Calificación promedio (2S) | 12.4% |
| 4 | Calificación promedio (1S) | 7.3% |
| 5 | Estado de matrícula | 5.6% |
| 6 | Edad al inscribirse | 4.3% |
| 7 | Evaluaciones (2S) | 4.0% |
| 8 | Evaluaciones (1S) | 3.6% |
| 9 | Código del curso | 3.4% |
| 10 | Unidades inscritas (2S) | 2.5% |

### Insights Clave
- 📚 El **rendimiento académico** (unidades aprobadas y calificaciones) representa el **53%** de la importancia total
- ⏰ El **desempeño del 2do semestre** es más predictivo que el 1er semestre
- 💰 El **estado financiero** (matrícula al día) es un factor crítico

---

## 📦 Contenido del Paquete

### Archivos Principales
```
student_retention_app/
├── 📱 app.py                    (Aplicación Streamlit - 12KB)
├── 🤖 model.pkl                 (Modelo entrenado - 8.9MB)
├── 🎓 train_model.py            (Script de entrenamiento - 2.8KB)
├── 📊 datos_estudiantes.csv     (Dataset - 460KB, 4,424 estudiantes)
├── ⚙️ scaler.pkl                (Escalador de datos - 2.2KB)
├── 🏷️ label_encoder.pkl        (Codificador - 275 bytes)
├── 📝 feature_names.pkl         (Nombres de características - 905 bytes)
└── 📋 requirements.txt          (Dependencias Python)
```

### Scripts de Instalación
- ✅ `install.bat` - Instalador automático Windows
- ✅ `install.sh` - Instalador automático Linux/Mac
- ✅ `run_app.bat` - Ejecutor Windows
- ✅ `run_app.sh` - Ejecutor Linux/Mac

### Documentación
- 📖 `README.md` - Guía completa (5.1KB)
- ⚡ `GUIA_RAPIDA.md` - Instalación express (2.1KB)
- 🌐 `INSTRUCCIONES.html` - Guía visual interactiva

---

## 🚀 Instalación en 3 Pasos

### Opción A: Instalación Automática (Recomendado)

#### Windows
```bash
1. Descomprimir student_retention_app.zip
2. Doble clic en: install.bat
3. Doble clic en: run_app.bat
```

#### Linux/Mac
```bash
1. Descomprimir student_retention_app.zip
2. chmod +x install.sh run_app.sh
3. ./install.sh
4. ./run_app.sh
```

### Opción B: Instalación Manual

```bash
# 1. Crear entorno virtual
python -m venv venv

# 2. Activar entorno
# Windows: venv\Scripts\activate
# Linux/Mac: source venv/bin/activate

# 3. Instalar dependencias
pip install -r requirements.txt

# 4. Entrenar modelo (ya incluido, opcional)
python train_model.py

# 5. Ejecutar app
streamlit run app.py
```

---

## 🎯 Características de la Aplicación

### 1️⃣ Predicción Individual
- ✅ Formulario interactivo con todas las variables
- ✅ Predicción en tiempo real
- ✅ Visualización de probabilidades con gráficos
- ✅ Interpretación clara del resultado

### 2️⃣ Predicción por Lote
- ✅ Carga de archivos CSV masivos
- ✅ Procesamiento de cientos de estudiantes simultáneamente
- ✅ Estadísticas agregadas y gráficos
- ✅ Descarga de resultados en CSV

### 3️⃣ Visualizaciones
- 📊 Gráficos de barras (probabilidades)
- 🥧 Gráficos de pastel (distribución)
- 📈 Métricas interactivas
- 🎨 Diseño moderno y profesional

---

## 🛠️ Tecnologías Utilizadas

| Tecnología | Versión | Propósito |
|------------|---------|-----------|
| **Python** | 3.8+ | Lenguaje base |
| **Streamlit** | 1.31.0 | Interfaz web |
| **scikit-learn** | 1.4.0 | Machine Learning |
| **pandas** | 2.1.4 | Procesamiento de datos |
| **numpy** | 1.26.3 | Cálculos numéricos |
| **plotly** | 5.18.0 | Visualizaciones |

---

## 📈 Dataset Utilizado

- **Registros:** 4,424 estudiantes
- **Características:** 34 variables predictoras
- **Target:** 3 categorías (Graduate, Dropout, Enrolled)
- **Distribución:**
  - 🎓 Graduate: 2,209 (49.9%)
  - ❌ Dropout: 1,421 (32.1%)
  - 📚 Enrolled: 794 (18.0%)

### Variables Categorizadas
- 👤 **Demográficas:** Edad, género, estado civil, nacionalidad
- 📚 **Académicas:** Modo de aplicación, curso, calificaciones, unidades
- 👨‍👩‍👧 **Familiares:** Educación y ocupación de padres
- 💰 **Económicas:** Becas, deudas, indicadores macroeconómicos

---

## ⚠️ Requisitos del Sistema

### Mínimos
- **Sistema Operativo:** Windows 7+, macOS 10.12+, Linux
- **Python:** 3.8 o superior
- **RAM:** 2 GB mínimo
- **Disco:** 500 MB espacio libre
- **Navegador:** Chrome, Firefox, Safari, Edge (actualizado)

### Recomendados
- **RAM:** 4 GB o más
- **Procesador:** Dual-core 2.0 GHz+
- **Conexión:** Internet (solo para instalación)

---

## 💡 Casos de Uso

### 1. Instituciones Educativas
- Identificar estudiantes en riesgo de abandono
- Planificar intervenciones tempranas
- Optimizar recursos de tutoría

### 2. Departamentos de Admisiones
- Evaluar candidatos durante el proceso de admisión
- Predecir tasas de retención por programa

### 3. Investigación Educativa
- Analizar factores que influyen en la retención
- Desarrollar políticas basadas en evidencia

### 4. Analistas de Datos
- Benchmark de modelos predictivos
- Estudio de características importantes

---

## 🔒 Privacidad y Seguridad

- ✅ **Procesamiento local:** Todos los datos se procesan en tu máquina
- ✅ **Sin conexión externa:** No se envía información a servidores externos
- ✅ **Sin recolección de datos:** La app no guarda historial de predicciones
- ✅ **Código abierto:** Todo el código es auditable

---

## 🎓 Próximos Pasos Sugeridos

### Mejoras del Modelo
1. **Aumentar datos de "Enrolled"** para mejorar su predicción
2. **Probar otros algoritmos:** XGBoost, LightGBM, Neural Networks
3. **Feature Engineering:** Crear variables derivadas
4. **Cross-validation:** Validación cruzada para mayor robustez

### Mejoras de la App
1. **Dashboard administrativo** con estadísticas históricas
2. **Sistema de alertas** para estudiantes en riesgo
3. **Exportar reportes PDF** automáticos
4. **Integración con sistemas** estudiantiles existentes

---

## 📞 Soporte

### Problemas Comunes
Consulta la sección "Solución de Problemas" en:
- `README.md` - Guía completa
- `GUIA_RAPIDA.md` - Soluciones rápidas
- `INSTRUCCIONES.html` - Guía visual

### Comandos Útiles
```bash
# Ver logs de Streamlit
streamlit run app.py --logger.level=debug

# Cambiar puerto
streamlit run app.py --server.port 8502

# Ver dependencias instaladas
pip list

# Actualizar streamlit
pip install --upgrade streamlit
```

---

## 📄 Licencia

Este proyecto es **código abierto** y está disponible para uso educativo y comercial.

---

## ✨ Conclusión

Has recibido una **aplicación completa de Machine Learning** lista para usar:

✅ **Modelo entrenado** con 78% de precisión  
✅ **Interfaz web moderna** con Streamlit  
✅ **Instalación automatizada** en todos los SO  
✅ **Documentación completa** y ejemplos  
✅ **Listo para producción** o educación  

**¡Comienza a predecir la retención estudiantil hoy mismo!** 🚀

---

*Última actualización: Febrero 2026*
*Desarrollado con 🐍 Python + 🤖 ML + 🎨 Streamlit*
